CCNP ENARSI
Curso: Path control y redistribución de rutas
Laboratorio: Redistribución de ruta IPv4
Firmware: Routers  -> c7200-advipservicesk9-mz.152-4.S5.bin
Autor: José Tomás López