CCNP ENARSI
Curso: Path control y redistribución de rutas
Laboratorio: Configuración PBR
Firmware: Routers  -> c7200-advipservicesk9-mz.152-4.S5.bin
Autor: José Tomás López